﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SpaceGame;
namespace SpaceGameTestProj
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            GlobalInventoryPrices GIP = new GlobalInventoryPrices();
            GIP.PlayerCash = 1000;
            Assert.AreEqual(1000, GIP.PlayerCash);
        }
    }
}
