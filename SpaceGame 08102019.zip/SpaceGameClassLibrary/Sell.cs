﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGame
{
    class Sell
    {
        GlobalInventoryPrices GIP = new GlobalInventoryPrices();
        GlobalInventory GI = new GlobalInventory();
        PlayerInventory PI = new PlayerInventory();
        public void SellInv()
        {
            Console.WriteLine("\nWhat would you like to sell?");            
            Console.WriteLine("Please type out the name of the item.");
            
            string s = Console.ReadLine();

            switch (s)
            {
                case "copper watch":
                case "copperwatch":
                    {
                        if (GIP.FenceCash > 85)
                        {
                            Console.WriteLine("You sold a copper watch for $85.\n");
                            GIP.PlayerCash += GIP.CopperWatch;
                            GIP.FenceCash -= GIP.CopperWatch;
                            PI.PlayerInv.Remove(GI.CopperWatch);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 85)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "copper plate":
                case "copperplate":
                    {
                        if (GIP.FenceCash > 20)
                        {
                            Console.WriteLine("You sold a copper plate for $20.\n");
                            GIP.PlayerCash += GIP.CopperPlate;
                            GIP.FenceCash -= GIP.CopperPlate;
                            PI.PlayerInv.Remove(GI.CopperPlate);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 20)
                        {
                            Console.WriteLine("The marketplace doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "copper stool":
                case "copperstool":
                    {
                        if (GIP.FenceCash > 50)
                        {
                            Console.WriteLine("You sold a copper stool for $50.\n");
                            GIP.PlayerCash += GIP.CopperStool;
                            GIP.FenceCash -= GIP.CopperStool;
                            PI.PlayerInv.Remove(GI.CopperStool);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 50)
                        {
                            Console.WriteLine("The marketplace doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "copper buckle":
                case "copperbuckle":
                    {
                        if (GIP.FenceCash > 25)
                        {
                            Console.WriteLine("You sold a copper buckle for $25.\n");
                            GIP.PlayerCash += GIP.CopperBuckle;
                            GIP.FenceCash -= GIP.CopperBuckle;
                            PI.PlayerInv.Remove(GI.CopperBuckle);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 25)
                        {
                            Console.WriteLine("The marketplace doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "copper statue":
                case "copperstatue":
                    {
                        if (GIP.FenceCash > 150)
                        {
                            Console.WriteLine("You sold a copper statue for $150.\n");
                            GIP.PlayerCash += GIP.CopperStatue;
                            GIP.FenceCash -= GIP.CopperStatue;
                            PI.PlayerInv.Remove(GI.CopperStatue);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 150)
                        {
                            Console.WriteLine("The marketplace doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "bronze watch":
                case "bronzewatch":
                    {
                        if (GIP.FenceCash > 95)
                        {
                            Console.WriteLine("You sold a bronze watch for $95.\n");
                            GIP.PlayerCash += GIP.BronzeWatch;
                            GIP.FenceCash -= GIP.BronzeWatch;
                            PI.PlayerInv.Remove(GI.BronzeWatch);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 95)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "bronze plate":
                case "bronzeplate":
                    {
                        if (GIP.FenceCash > 25)
                        {
                            Console.WriteLine("You sold a bronze plate for $25.\n");
                            GIP.PlayerCash += GIP.BronzePlate;
                            GIP.FenceCash -= GIP.BronzePlate;
                            PI.PlayerInv.Remove(GI.BronzePlate);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 25)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "bronze stool":
                case "bronzestool":
                    {
                        if (GIP.FenceCash > 60)
                        {
                            Console.WriteLine("You sold a bronze stool for $60.\n");
                            GIP.PlayerCash += GIP.BronzeStool;
                            GIP.FenceCash -= GIP.BronzeStool;
                            PI.PlayerInv.Remove(GI.BronzeStool);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 60)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "bronze buckle":
                case "bronzebuckle":
                    {
                        if (GIP.FenceCash > 30)
                        {
                            Console.WriteLine("You sold a bronze buckle for $30.\n");
                            GIP.PlayerCash += GIP.BronzeBuckle;
                            GIP.FenceCash -= GIP.BronzeBuckle;
                            PI.PlayerInv.Remove(GI.BronzeBuckle);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 30)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "bronze statue":
                case "bronzestatue":
                    {
                        if (GIP.FenceCash > 175)
                        {
                            Console.WriteLine("You sold a bronze statue for $175.\n");
                            GIP.PlayerCash += GIP.BronzeStatue;
                            GIP.FenceCash -= GIP.BronzeStatue;
                            PI.PlayerInv.Remove(GI.BronzeStatue);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 175)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "silver watch":
                case "silverwatch":
                    {
                        if (GIP.FenceCash > 110)
                        {
                            Console.WriteLine("You sold a silver watch for $110.\n");
                            GIP.PlayerCash += GIP.SilverWatch;
                            GIP.FenceCash -= GIP.SilverWatch;
                            PI.PlayerInv.Remove(GI.SilverWatch);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 110)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "silver plate":
                case "silverplate":
                    {
                        if (GIP.FenceCash > 35)
                        {
                            Console.WriteLine("You sold a silver plate for $35.\n");
                            GIP.PlayerCash += GIP.SilverPlate;
                            GIP.FenceCash -= GIP.SilverPlate;
                            PI.PlayerInv.Remove(GI.SilverPlate);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 35)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "silver stool":
                case "silverstool":
                    {
                        if (GIP.FenceCash > 75)
                        {
                            Console.WriteLine("You sold a silver stool for $75.\n");
                            GIP.PlayerCash += GIP.SilverStool;
                            GIP.FenceCash -= GIP.SilverStool;
                            PI.PlayerInv.Remove(GI.SilverStool);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 75)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "silver buckle":
                case "silverbuckle":
                    {
                        if (GIP.FenceCash > 40)
                        {
                            Console.WriteLine("You sold a silver buckle for $40.\n");
                            GIP.PlayerCash += GIP.SilverBuckle;
                            GIP.FenceCash -= GIP.SilverBuckle;
                            PI.PlayerInv.Remove(GI.SilverBuckle);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 40)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "silver statue":
                case "silverstatue":
                    {
                        if (GIP.FenceCash > 200)
                        {
                            Console.WriteLine("You sold a silver statue for $200.\n");
                            GIP.PlayerCash += GIP.SilverStatue;
                            GIP.FenceCash -= GIP.SilverStatue;
                            PI.PlayerInv.Remove(GI.SilverStatue);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 200)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "gold watch":
                case "goldwatch":
                    {
                        if (GIP.FenceCash > 125)
                        {
                            Console.WriteLine("You sold a gold watch for $125.\n");
                            GIP.PlayerCash += GIP.GoldWatch;
                            GIP.FenceCash -= GIP.GoldWatch;
                            PI.PlayerInv.Remove(GI.GoldWatch);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 125)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "gold plate":
                case "goldplate":
                    {
                        if (GIP.FenceCash > 45)
                        {
                            Console.WriteLine("You sold a gold plate for $45.\n");
                            GIP.PlayerCash += GIP.GoldPlate;
                            GIP.FenceCash -= GIP.GoldPlate;
                            PI.PlayerInv.Remove(GI.GoldPlate);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 45)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "gold stool":
                case "goldstool":
                    {
                        if (GIP.FenceCash > 85)
                        {
                            Console.WriteLine("You sold a gold stool for $85.\n");
                            GIP.PlayerCash += GIP.GoldStool;
                            GIP.FenceCash -= GIP.GoldStool;
                            PI.PlayerInv.Remove(GI.GoldStool);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 85)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "gold buckle":
                case "goldbuckle":
                    {
                        if (GIP.FenceCash > 50)
                        {
                            Console.WriteLine("You sold a gold buckle for $50.\n");
                            GIP.PlayerCash += GIP.GoldBuckle;
                            GIP.FenceCash -= GIP.GoldBuckle;
                            PI.PlayerInv.Remove(GI.GoldBuckle);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 50)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "gold statue":
                case "goldstatue":
                    {
                        if (GIP.FenceCash > 225)
                        {
                            Console.WriteLine("You sold a gold statue for $200.\n");
                            GIP.PlayerCash += GIP.GoldStatue;
                            GIP.FenceCash -= GIP.GoldStatue;
                            PI.PlayerInv.Remove(GI.GoldStatue);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 225)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "platinum watch":
                case "platinumwatch":
                    {
                        if (GIP.FenceCash > 150)
                        {
                            Console.WriteLine("You sold a platinum watch for $150.\n");
                            GIP.PlayerCash += GIP.PlatinumWatch;
                            GIP.FenceCash -= GIP.PlatinumWatch;
                            PI.PlayerInv.Remove(GI.PlatinumWatch);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 150)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "platinum plate":
                case "platinumplate":
                    {
                        if (GIP.FenceCash > 60)
                        {
                            Console.WriteLine("You sold a platinum plate for $60.\n");
                            GIP.PlayerCash += GIP.PlatinumPlate;
                            GIP.FenceCash -= GIP.PlatinumPlate;
                            PI.PlayerInv.Remove(GI.PlatinumPlate);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 60)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "platinum stool":
                case "platinumstool":
                    {
                        if (GIP.FenceCash > 100)
                        {
                            Console.WriteLine("You sold a platinum stool for $100.\n");
                            GIP.PlayerCash += GIP.PlatinumStool;
                            GIP.FenceCash -= GIP.PlatinumStool;
                            PI.PlayerInv.Remove(GI.PlatinumStool);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 100)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "platinum buckle":
                case "platinumbuckle":
                    {
                        if (GIP.FenceCash > 65)
                        {
                            Console.WriteLine("You sold a platinum buckle for $65.\n");
                            GIP.PlayerCash += GIP.PlatinumBuckle;
                            GIP.FenceCash -= GIP.PlatinumBuckle;
                            PI.PlayerInv.Remove(GI.PlatinumBuckle);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 65)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                case "platinum statue":
                case "platinumstatue":
                    {
                        if (GIP.FenceCash > 250)
                        {
                            Console.WriteLine("You sold a platinum statue for $250.\n");
                            GIP.PlayerCash += GIP.PlatinumStatue;
                            GIP.FenceCash -= GIP.PlatinumStatue;
                            PI.PlayerInv.Remove(GI.PlatinumStatue);
                            Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                            Console.WriteLine("Press enter to return to the store.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        if (GIP.FenceCash < 250)
                        {
                            Console.WriteLine("The fence doesn't have the money to buy this right now.\n");
                            Console.WriteLine("Press enter to return to the market.\n");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Command not recognized. Try again.");
                        break;
                    }

            }
        }
    }
}
