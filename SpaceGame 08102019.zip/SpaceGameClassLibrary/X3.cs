﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGame
{
    public class X3
    {
        GlobalInventoryPrices GIP = new GlobalInventoryPrices();
        GlobalInventory GI = new GlobalInventory();
        PlayerInventory PI = new PlayerInventory();
        public void X3Prison()
        {
            Typewrite("You have been in prison for the last 10 years for larceny. You awake and say\n");
            Typewrite("'Today is the day! It's time to reclaim my freedom!'");
            Typewrite($"A guard comes to your cell and says \n 'Time to go. I need your cell for the new guy.\n' ");
            Typewrite("You walk out of the prison.");
            Typewrite("\nYou smell the fresh air and realize you \nnever want to spend anymore time in that prison ever again.");
            Typewrite("\nA stranger comes up and greats you....\nWelcome to Planet X3!");
            Typewrite("\nWe have the galaxies most secure prison! You best be careful around these parts!");
            Typewrite("\nYou look like you're someone we have to keep an eye on, I saw you leave the prison.");
            Typewrite("\nDont go causing any trouble around here. We have plenty of that around here already.");
            Typewrite("\nGo to the market and buy or sell your stuff or leave.. \ndoesn't matter to me... \njust no funny bussiness.");
            Typewrite("\nDon't even think about staying here long-term either.. \nwe dont have enough room as it is.");
            Typewrite("\nPress 'Enter' to continue.");
            Console.ReadLine();
            Console.Clear();
        }
        public void X3Welcome()
        {
            string Choice;

            Typewrite("\nWhat would you like to do?");
            Typewrite("\n1. Go to the next planet");
            Typewrite("\n2. Go to the market and see whats around.\n");
            Typewrite("Choice: ");
            Choice = Console.ReadLine().ToLower();

            switch (Choice)
            {
                case "1":
                case "one":
                    Console.Clear();
                    Viz viz = new Viz();
                    viz.VizWelcome();
                    break;
                case "2":
                case "two":
                    Console.Clear();
                    X3Market();
                    break;
                default:
                    Typewrite("Please choose '1' or '2'!");
                    Typewrite("Press 'Enter' to try again.");
                    Console.ReadLine();
                    Console.Clear();
                    X3Welcome();
                    break;
            }
        }
        public void X3Market()
        {
            Console.WriteLine("Welcome to the X3 Market! What would you like to do?");
            Console.WriteLine("1] >> Buy Items ");
            Console.WriteLine("2] >> Sell Items ");
            Console.WriteLine("3] >> Travel");
            string input = Console.ReadLine().ToLower();
            Console.Clear();

            switch (input)
            {
                case "1":
                case "buy":
                    {
                        Console.WriteLine($"You have ${GIP.PlayerCash}");
                        Console.WriteLine("What would you like to buy?");
                        Console.WriteLine("       Item                 Cost     ");
                        Console.WriteLine("      -------              ------    ");
                        Console.WriteLine("1]  Copper Watch            $85      ");
                        Console.WriteLine("2]  Copper Plate            $20      ");
                        Console.WriteLine("3]  Copper Stool            $50      ");
                        Console.WriteLine("4]  Copper Buckle           $25      ");
                        Console.WriteLine("5]  Copper Statue           $150     ");
                        Console.WriteLine("6]  Cancel purchase                  ");
                        int choice = Int32.Parse(Console.ReadLine());

                        switch (choice)
                        {
                            case 1:
                                {
                                    if (GIP.PlayerCash >= 85)
                                    {
                                        Console.WriteLine("You bought a copper watch for $85.\n");
                                        GIP.PlayerCash -= GIP.CopperWatch;
                                        GIP.X3Cash += GIP.CopperWatch;
                                        PI.PlayerInv.Add(GI.CopperWatch);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        X3Market();
                                    }
                                    if (GIP.PlayerCash < 85)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.\n");
                                        Console.WriteLine("Maybe try selling a few of your items.");
                                        Console.WriteLine("Press enter to return to the market.\n");
                                        Console.ReadLine();
                                        Console.Clear();
                                        X3Market();
                                    }
                                    break;
                                }
                            case 2:
                                {
                                    if (GIP.PlayerCash >= 20)
                                    {
                                        Console.WriteLine("You bought a copper plate for $20.\n");
                                        GIP.PlayerCash -= GIP.CopperPlate;
                                        GIP.X3Cash += GIP.CopperPlate;
                                        PI.PlayerInv.Add(GI.CopperPlate);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        X3Market();
                                    }
                                    if (GIP.PlayerCash < 20)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        X3Market();
                                    }
                                    break;
                                }
                            case 3:
                                {
                                    if (GIP.PlayerCash >= 50)
                                    {
                                        Console.WriteLine("You bought a copper stool for $50.\n");
                                        GIP.PlayerCash -= GIP.CopperStool;
                                        GIP.X3Cash += GIP.CopperStool;
                                        PI.PlayerInv.Add(GI.CopperStool);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        X3Market();
                                    }
                                    if (GIP.PlayerCash < 50)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        X3Market();
                                    }
                                    break;
                                }
                            case 4:
                                {
                                    if (GIP.PlayerCash >= 25)
                                    {
                                        Console.WriteLine("You bought a copper buckle for $25.\n");
                                        GIP.PlayerCash -= GIP.CopperBuckle;
                                        GIP.X3Cash += GIP.CopperBuckle;
                                        PI.PlayerInv.Add(GI.CopperBuckle);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        X3Market();
                                    }
                                    if (GIP.PlayerCash < 25)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        X3Market();
                                    }
                                    break;
                                }
                            case 5:
                                {
                                    if (GIP.PlayerCash >= 150)
                                    {
                                        Console.WriteLine("You bought a copper statue for $150.\n");
                                        GIP.PlayerCash -= GIP.CopperStatue;
                                        GIP.X3Cash += GIP.CopperStatue;
                                        PI.PlayerInv.Add(GI.CopperStatue);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        X3Market();
                                    }
                                    if (GIP.PlayerCash < 150)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        X3Market();
                                    }
                                    break;
                                }
                            case 6:
                                {
                                    X3Market();
                                    break;
                                }

                        }
                        
                        break;
                    }
                case "2":
                case "sell":
                    {
                        Console.WriteLine("        YOUR INVENTORY        ");
                        Console.WriteLine("==============================");
                        Console.WriteLine("   Item             Cost     ");
                        Console.WriteLine("  -------          ------    ");
                        PI.PIdisplay();
                        Sell sell2 = new Sell();
                        sell2.SellInv();
                        Console.ReadLine();
                        break;
                    }
                case "3":
                case "travel":
                    {
                        Console.WriteLine("What planet would you like to travel to?\n");
                        Console.WriteLine("1]  Planet Viz");
                        Console.WriteLine("2]  Planet Horn");
                        Console.WriteLine("3]  Planet Gil");
                        Console.WriteLine("4]  Planet DOOM");
                        Console.WriteLine("5]  Cancel");
                        int c = Int32.Parse(Console.ReadLine());

                        switch (c)
                        {
                            case 1:
                                {
                                    Console.Clear();
                                    Viz viz = new Viz();
                                    viz.VizWelcome();
                                    break;
                                }
                            case 2:
                                {
                                    Console.Clear();
                                    Horn horn = new Horn();
                                    horn.HornWelcome();
                                    break;
                                }
                            case 3:
                                {
                                    Console.Clear();
                                    Gil gil = new Gil();
                                    gil.GilWelcome();
                                    break;
                                }
                            case 4:
                                {
                                    Console.Clear();
                                    DOOM doom = new DOOM();
                                    doom.DoomWelcome();
                                    break;
                                }
                            case 5:
                                {
                                    Console.Clear();
                                    X3Market();
                                    break;
                                }
                            default:
                                {
                                    Console.WriteLine("Command not recognized. Try again.");
                                    break;
                                }

                        }
                        break;
                    }
            }
        }
        public void Typewrite(string message)
        {
            for (int i = 0; i < message.Length; i++)
            {
                Console.Write(message[i]);
                System.Threading.Thread.Sleep(10);
            }
        }
    }
}

    

