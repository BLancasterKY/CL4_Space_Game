﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGame
{
    class Viz
    {
        GlobalInventoryPrices GIP = new GlobalInventoryPrices();
        GlobalInventory GI = new GlobalInventory();
        PlayerInventory PI = new PlayerInventory();
        public void VizWelcome()
        {
            string Choice; 

            Typewrite("You teleport to planet Viz and a stranger walks up to you in a raggedy suit... \nWelcome to Planet Viz! \nWe are a kind people, \nmost people who visit end up never leaving..");
            Typewrite("\nYou get an odd feeling from the man and notice he has a very strange look on his face.");
            Typewrite("\nYou think to yourself.. best not stay here long.. \nthese people have the shakes and looks like they are possibly cannibals.");
            Typewrite("\nPeople who spend time here never end up leaving...");
            Typewrite("\nWhat would you like to do?");
            Typewrite("\n1. Go to the next planet");
            Typewrite("\n2. Go to the market and see whats around.");
            Typewrite("Choice: ");
            Choice = Console.ReadLine().ToLower();
            Console.Clear();

            switch (Choice)
            {
                case "1":
                case "one":
                    Console.Clear();
                    Horn horn = new Horn();
                    horn.HornWelcome();
                    break;
                case "2":
                case "two":
                    Console.Clear();
                    VizMarket();
                    break;
                default:
                    Typewrite("Please choose '1' or '2'!");
                    Typewrite("Press 'Enter' to try again.");
                    Console.ReadLine();
                    Console.Clear();
                    VizWelcome();
                    break;
            }
        }
        public void VizMarket()
        {
            Typewrite("Welcome to the Planet Viz Market! Feel free to look around.");
            Typewrite("\n1] >> Buy Items ");
            Typewrite("\n2] >> Sell Items ");
            Typewrite("\n3] >> Travel");
            string input = Console.ReadLine().ToLower();
            Console.Clear();

            switch (input)
            {
                case "1":
                case "buy":
                    {
                        Console.WriteLine($"You have ${GIP.PlayerCash}");
                        Console.WriteLine("What would you like to buy?");
                        Console.WriteLine("       Item                 Cost     ");
                        Console.WriteLine("      -------              ------    ");
                        Console.WriteLine("1]  Bronze Watch            $95      ");
                        Console.WriteLine("2]  Bronze Plate            $25      ");
                        Console.WriteLine("3]  Bronze Stool            $60      ");
                        Console.WriteLine("4]  Bronze Buckle           $30      ");
                        Console.WriteLine("5]  Bronze Statue           $175     ");
                        Console.WriteLine("6]  Cancel purchase                  ");
                        int choice = Int32.Parse(Console.ReadLine());

                        switch (choice)
                        {
                            case 1:
                                {
                                    if (GIP.PlayerCash >= 95)
                                    {
                                        Console.WriteLine("You bought a bronze watch for $95.\n");
                                        GIP.PlayerCash -= GIP.BronzeWatch;
                                        GIP.VizCash += GIP.BronzeWatch;
                                        PI.PlayerInv.Add(GI.BronzeWatch);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine($"Planet Viz Martketplace now has ${GIP.VizCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        VizMarket();
                                    }
                                    if (GIP.PlayerCash < 95)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.\n");
                                        Console.WriteLine("Maybe try selling a few of your items.");
                                        Console.WriteLine("Press enter to return to the market.\n");
                                        Console.ReadLine();
                                        Console.Clear();
                                        VizMarket();
                                    }
                                    break;
                                }
                            case 2:
                                {
                                    if (GIP.PlayerCash >= 25)
                                    {
                                        Console.WriteLine("You bought a bronze plate for $25.\n");
                                        GIP.PlayerCash -= GIP.BronzePlate;
                                        GIP.VizCash += GIP.BronzePlate;
                                        PI.PlayerInv.Add(GI.BronzePlate);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine($"Planet Viz Martketplace now has ${GIP.VizCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        VizMarket();
                                    }
                                    if (GIP.PlayerCash < 25)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        VizMarket();
                                    }
                                    break;
                                }
                            case 3:
                                {
                                    if (GIP.PlayerCash >= 60)
                                    {
                                        Console.WriteLine("You bought a bronze stool for $60.\n");
                                        GIP.PlayerCash -= GIP.BronzeStool;
                                        GIP.VizCash += GIP.BronzeStool;
                                        PI.PlayerInv.Add(GI.BronzeStool);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine($"Planet Viz Martketplace now has ${GIP.VizCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        VizMarket();
                                    }
                                    if (GIP.PlayerCash < 60)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        VizMarket();
                                    }
                                    break;
                                }
                            case 4:
                                {
                                    if (GIP.PlayerCash >= 30)
                                    {
                                        Console.WriteLine("You bought a bronze buckle for $30.\n");
                                        GIP.PlayerCash -= GIP.BronzeBuckle;
                                        GIP.VizCash += GIP.BronzeBuckle;
                                        PI.PlayerInv.Add(GI.BronzeBuckle);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine($"Planet Viz Martketplace now has ${GIP.VizCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        VizMarket();
                                    }
                                    if (GIP.PlayerCash < 25)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        VizMarket();
                                    }
                                    break;
                                }
                            case 5:
                                {
                                    if (GIP.PlayerCash >= 175)
                                    {
                                        Console.WriteLine("You bought a bronze statue for $175.\n");
                                        GIP.PlayerCash -= GIP.CopperStatue;
                                        GIP.VizCash += GIP.CopperStatue;
                                        PI.PlayerInv.Add(GI.CopperStatue);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine($"Planet Viz Martketplace now has ${GIP.VizCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        VizMarket();
                                    }
                                    if (GIP.PlayerCash < 175)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        VizMarket();
                                    }
                                    break;
                                }
                            case 6:
                                {
                                    VizMarket();
                                    break;
                                }

                        }

                        break;
                    }
                case "2":
                case "sell":
                    {
                        Console.WriteLine("        YOUR INVENTORY        ");
                        Console.WriteLine("==============================");
                        Console.WriteLine("   Item             Cost     ");
                        Console.WriteLine("  -------          ------    ");
                        PI.PIdisplay();
                        Sell sell2 = new Sell();
                        sell2.SellInv();
                        Console.ReadLine();
                        break;
                    }
                case "3":
                case "travel":
                    {
                        Console.WriteLine("What planet would you like to travel to?\n");
                        Console.WriteLine("1]  Planet X3");
                        Console.WriteLine("2]  Planet Horn");
                        Console.WriteLine("3]  Planet Gil");
                        Console.WriteLine("4]  Planet DOOM");
                        Console.WriteLine("5]  Cancel");
                        int c = Int32.Parse(Console.ReadLine());

                        switch (c)
                        {
                            case 1:
                                {
                                    Console.Clear();
                                    X3 x3 = new X3();
                                    x3.X3Welcome();
                                    break;
                                }
                            case 2:
                                {
                                    Console.Clear();
                                    Horn horn = new Horn();
                                    horn.HornWelcome();
                                    break;
                                }
                            case 3:
                                {
                                    Console.Clear();
                                    Gil gil = new Gil();
                                    gil.GilWelcome();
                                    break;
                                }
                            case 4:
                                {
                                    Console.Clear();
                                    DOOM doom = new DOOM();
                                    doom.DoomWelcome();
                                    break;
                                }
                            case 5:
                                {
                                    Console.Clear();
                                    VizMarket();
                                    break;
                                }
                            default:
                                {
                                    Console.WriteLine("Command not recognized. Try again.");
                                    break;
                                }

                        }
                        break;
                    }
            }
        }
        void Typewrite(string message)
        {
            for (int i = 0; i < message.Length; i++)
            {
                Console.Write(message[i]);
                System.Threading.Thread.Sleep(50);
            }
        }
    }
}
