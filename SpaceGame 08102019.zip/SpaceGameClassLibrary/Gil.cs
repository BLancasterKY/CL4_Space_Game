﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGame
{
    class Gil
    {
        GlobalInventoryPrices GIP = new GlobalInventoryPrices();
        GlobalInventory GI = new GlobalInventory();
        PlayerInventory PI = new PlayerInventory();
        public void GilWelcome()
        {
            string Choice;

            Typewrite("\nWelcome to planet Gil!");
            Typewrite("\nWe are very by the book here and have the lowest crime in the galaxy.");
            Typewrite("\nPeople from all over the galaxy come here to vacation, retire, you name it!");
            Typewrite("\nYou'll find we are a kind people and love to help out any way we can!");
            Typewrite("\nEnjoy your time here!");
            Typewrite("\nWhat would you like to do?");
            Typewrite("\n1. Go to the next planet");
            Typewrite("\n2. Go to the nearest vendor.");
            Typewrite("Choice: ");
            Choice = Console.ReadLine().ToLower();
            Console.Clear();

            switch (Choice)
            {
                case "1":
                case "one":
                    Console.Clear();
                    DOOM doom = new DOOM();
                    doom.DoomWelcome();
                    break;
                case "2":
                case "two":
                    Console.Clear();
                    GilMarket();
                    break;
                default:
                    Typewrite("Please choose '1' or '2'!");
                    Typewrite("Press 'Enter' to try again.");
                    Console.ReadLine();
                    Console.Clear();
                    GilWelcome();
                    break;
            }
        }
        public void GilMarket()
        {
            Typewrite("You walk to the market on planet gil and see there is \n only one man with a cart sitting in the open.");
            Typewrite("\nYou walk up to the man..");
            Typewrite("\nOh! Welcome to my shop! Everyone's over at the arena today watching the big fight!");
            Typewrite("\nI'm still open though so please feel free to browse my wares!");
            Typewrite("\nWhat would you like to do?");
            Typewrite("1] >> Buy Items ");
            Typewrite("2] >> Sell Items ");
            Typewrite("3] >> Travel");
            string input = Console.ReadLine().ToLower();
            Console.Clear();

            switch (input)
            {
                case "1":
                case "buy":
                    {
                        Typewrite($"You have ${GIP.PlayerCash}");
                        Console.WriteLine("What would you like to buy?");
                        Console.WriteLine("       Item                 Cost     ");
                        Console.WriteLine("      -------              ------    ");
                        Console.WriteLine("1]  Gold Watch              $125     ");
                        Console.WriteLine("2]  Gold Plate              $45      ");
                        Console.WriteLine("3]  Gold Stool              $85      ");
                        Console.WriteLine("4]  Gold Buckle             $50      ");
                        Console.WriteLine("5]  Gold Statue             $225     ");
                        Console.WriteLine("6]  Cancel purchase                  ");
                        int choice = Int32.Parse(Console.ReadLine());

                        switch (choice)
                        {
                            case 1:
                                {
                                    if (GIP.PlayerCash >= 125)
                                    {
                                        Console.WriteLine("You bought a gold watch for $125.\n");
                                        GIP.PlayerCash -= GIP.GoldWatch;
                                        GIP.GilCash += GIP.GoldWatch;
                                        PI.PlayerInv.Add(GI.GoldWatch);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        GilMarket();
                                    }
                                    if (GIP.PlayerCash < 125)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.\n");
                                        Console.WriteLine("Maybe try selling a few of your items.");
                                        Console.WriteLine("Press enter to return to the market.\n");
                                        Console.ReadLine();
                                        Console.Clear();
                                        GilMarket();
                                    }
                                    break;
                                }
                            case 2:
                                {
                                    if (GIP.PlayerCash >= 45)
                                    {
                                        Console.WriteLine("You bought a gold plate for $45.\n");
                                        GIP.PlayerCash -= GIP.GoldPlate;
                                        GIP.GilCash += GIP.GoldPlate;
                                        PI.PlayerInv.Add(GI.GoldPlate);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        GilMarket();
                                    }
                                    if (GIP.PlayerCash < 45)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        GilMarket();
                                    }
                                    break;
                                }
                            case 3:
                                {
                                    if (GIP.PlayerCash >= 85)
                                    {
                                        Console.WriteLine("You bought a gold stool for $85.\n");
                                        GIP.PlayerCash -= GIP.GoldStool;
                                        GIP.GilCash += GIP.GoldStool;
                                        PI.PlayerInv.Add(GI.GoldStool);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        GilMarket();
                                    }
                                    if (GIP.PlayerCash < 85)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        GilMarket();
                                    }
                                    break;
                                }
                            case 4:
                                {
                                    if (GIP.PlayerCash >= 50)
                                    {
                                        Console.WriteLine("You bought a gold buckle for $50.\n");
                                        GIP.PlayerCash -= GIP.GoldBuckle;
                                        GIP.GilCash += GIP.GoldBuckle;
                                        PI.PlayerInv.Add(GI.GoldBuckle);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        GilMarket();
                                    }
                                    if (GIP.PlayerCash < 50)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        GilMarket();
                                    }
                                    break;
                                }
                            case 5:
                                {
                                    if (GIP.PlayerCash >= 225)
                                    {
                                        Console.WriteLine("You bought a gold statue for $225.\n");
                                        GIP.PlayerCash -= GIP.GoldStatue;
                                        GIP.GilCash += GIP.GoldStatue;
                                        PI.PlayerInv.Add(GI.GoldStatue);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        GilMarket();
                                    }
                                    if (GIP.PlayerCash < 225)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        GilMarket();
                                    }
                                    break;
                                }
                            case 6:
                                {
                                    GilMarket();
                                    break;
                                }

                        }

                        break;
                    }
                case "2":
                case "sell":
                    {
                        Console.WriteLine("        YOUR INVENTORY        ");
                        Console.WriteLine("==============================");
                        Console.WriteLine("   Item             Cost     ");
                        Console.WriteLine("  -------          ------    ");
                        PI.PIdisplay();
                        Sell sell2 = new Sell();
                        sell2.SellInv();
                        Console.ReadLine();
                        break;
                    }
                case "3":
                case "travel":
                    {
                        Console.WriteLine("What planet would you like to travel to?\n");
                        Console.WriteLine("1]  Planet X3");
                        Console.WriteLine("2]  Planet Viz");
                        Console.WriteLine("3]  Planet Horn");
                        Console.WriteLine("4]  Planet DOOM");
                        Console.WriteLine("5]  Cancel");
                        int c = Int32.Parse(Console.ReadLine());

                        switch (c)
                        {
                            case 1:
                                {
                                    Console.Clear();
                                    X3 x3 = new X3();
                                    x3.X3Welcome();
                                    break;
                                }
                            case 2:
                                {
                                    Console.Clear();
                                    Viz viz = new Viz();
                                    viz.VizWelcome();
                                    break;
                                }
                            case 3:
                                {
                                    Console.Clear();
                                    Horn horn = new Horn();
                                    horn.HornWelcome();
                                    break;
                                }
                            case 4:
                                {
                                    Console.Clear();
                                    DOOM doom = new DOOM();
                                    doom.DoomWelcome();
                                    break;
                                }
                            case 5:
                                {
                                    Console.Clear();
                                    GilMarket();
                                    break;
                                }
                            default:
                                {
                                    Console.WriteLine("Command not recognized. Try again.");
                                    break;
                                }
                                
                        }
                        break;
                    }

            }
        }
        void Typewrite(string message)
        {
            for (int i = 0; i < message.Length; i++)
            {
                Console.Write(message[i]);
                System.Threading.Thread.Sleep(50);
            }
        }
    }
}
