﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGame
{
    class DOOM
    {
        GlobalInventoryPrices GIP = new GlobalInventoryPrices();
        GlobalInventory GI = new GlobalInventory();
        PlayerInventory PI = new PlayerInventory();
        public void DoomWelcome()
        {
            string Choice;

            Typewrite("You teleport to planet Doom and immediately feel how hot it is when you arrive!");
            Typewrite("\nYou notice there are flames and burning buildings everywhere!");
            Typewrite("\nAs you look around you see demons roaming the streets and people being murdered all around you!");
            Typewrite("\nBest be on high alert here.. \ncrime seems to be a normal way of life here");
            Typewrite("\nWhat would you like to do?");
            Typewrite("\n1. Go to the Market");
            Typewrite("\n2. Join in on the massacre!");
            Typewrite("Choice: ");
            Choice = Console.ReadLine().ToLower();
            Console.Clear();

            switch (Choice)
            {
                case "1":
                case "one":
                    Console.Clear();
                    DoomMarket();
                    break;
                case "2":
                case "two":
                    Console.Clear();
                    Typewrite("You grab a sword out of the body lying next to you!");
                    Typewrite("\nYou begin joining in on the massacre!");
                    Typewrite("Game... Over....");
                    Typewrite("You failed to travel and buy all the items in the galaxy!");
                    Typewrite("Press 'enter' to continue...");
                    Console.ReadLine();
                    Player player = new Player();
                    player.Welcome();
                    break;
                default:
                    Typewrite("Please choose '1' or '2'!");
                    Typewrite("Press 'Enter' to try again.");
                    Console.ReadLine();
                    Console.Clear();
                    DoomWelcome();
                    break;

            }
        }
        public void DoomMarket()
        {
            Typewrite("You quickly make your way to the market as you sweat profusely!");
            Typewrite("\nAs you arrive you see platinum items laid out all over the ground in front of vendors.");
            Typewrite("You approach the nearest vendor.\n");
            Typewrite("Welcome to the Planet DOOM Market! What would you like to do?");
            Typewrite("1] >> Buy Items ");
            Typewrite("2] >> Sell Items ");
            Typewrite("3] >> Travel");
            string input = Console.ReadLine().ToLower();
            Console.Clear();

            switch (input)
            {
                case "1":
                case "buy":
                    {
                        Typewrite($"You have ${GIP.PlayerCash}");
                        Typewrite("What would you like to buy?");
                        Console.WriteLine("        Item                    Cost     ");
                        Console.WriteLine("       -------                 ------    ");
                        Console.WriteLine("1]  Platinum Watch              $150     ");
                        Console.WriteLine("2]  Platinum Plate              $60      ");
                        Console.WriteLine("3]  Platinum Stool              $100     ");
                        Console.WriteLine("4]  Platinum Buckle             $65      ");
                        Console.WriteLine("5]  Platinum Statue             $250     ");
                        Console.WriteLine("6]  Cancel purchase                      ");
                        int choice = Int32.Parse(Console.ReadLine());

                        switch (choice)
                        {
                            case 1:
                                {
                                    if (GIP.PlayerCash >= 150)
                                    {
                                        Console.WriteLine("You bought a platinum watch for $150.\n");
                                        GIP.PlayerCash -= GIP.PlatinumWatch;
                                        GIP.DoomCash += GIP.PlatinumWatch;
                                        PI.PlayerInv.Add(GI.PlatinumWatch);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine($"Planet DOOM Martketplace now has ${GIP.DoomCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        DoomMarket();
                                    }
                                    if (GIP.PlayerCash < 150)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.\n");
                                        Console.WriteLine("Maybe try selling a few of your items.");
                                        Console.WriteLine("Press enter to return to the market.\n");
                                        Console.ReadLine();
                                        Console.Clear();
                                        DoomMarket();
                                    }
                                    break;
                                }
                            case 2:
                                {
                                    if (GIP.PlayerCash >= 60)
                                    {
                                        Console.WriteLine("You bought a platinum plate for $60.\n");
                                        GIP.PlayerCash -= GIP.PlatinumPlate;
                                        GIP.DoomCash += GIP.PlatinumPlate;
                                        PI.PlayerInv.Add(GI.PlatinumPlate);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine($"Planet DOOM Martketplace now has ${GIP.DoomCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        DoomMarket();
                                    }
                                    if (GIP.PlayerCash < 60)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        DoomMarket();
                                    }
                                    break;
                                }
                            case 3:
                                {
                                    if (GIP.PlayerCash >= 100)
                                    {
                                        Console.WriteLine("You bought a platinum stool for $100.\n");
                                        GIP.PlayerCash -= GIP.PlatinumStool;
                                        GIP.DoomCash += GIP.PlatinumStool;
                                        PI.PlayerInv.Add(GI.PlatinumStool);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine($"Planet DOOM Martketplace now has ${GIP.DoomCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        DoomMarket();
                                    }
                                    if (GIP.PlayerCash < 100)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        DoomMarket();
                                    }
                                    break;
                                }
                            case 4:
                                {
                                    if (GIP.PlayerCash >= 65)
                                    {
                                        Console.WriteLine("You bought a platinum buckle for $65.\n");
                                        GIP.PlayerCash -= GIP.PlatinumBuckle;
                                        GIP.DoomCash += GIP.PlatinumBuckle;
                                        PI.PlayerInv.Add(GI.PlatinumBuckle);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine($"Planet DOOM Martketplace now has ${GIP.DoomCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        DoomMarket();
                                    }
                                    if (GIP.PlayerCash < 65)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        DoomMarket();
                                    }
                                    break;
                                }
                            case 5:
                                {
                                    if (GIP.PlayerCash >= 250)
                                    {
                                        Console.WriteLine("You bought a platinum statue for $250.\n");
                                        GIP.PlayerCash -= GIP.PlatinumStatue;
                                        GIP.DoomCash += GIP.PlatinumStatue;
                                        PI.PlayerInv.Add(GI.PlatinumStatue);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine($"Planet DOOM Martketplace now has ${GIP.DoomCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        DoomMarket();
                                    }
                                    if (GIP.PlayerCash < 250)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        DoomMarket();
                                    }
                                    break;
                                }
                            case 6:
                                {
                                    DoomMarket();
                                    break;
                                }

                        }

                        break;
                    }
                case "2":
                case "sell":
                    {
                        Console.WriteLine("        YOUR INVENTORY        ");
                        Console.WriteLine("==============================");
                        Console.WriteLine("   Item             Cost     ");
                        Console.WriteLine("  -------          ------    ");
                        PI.PIdisplay();
                        Sell sell2 = new Sell();
                        sell2.SellInv();
                        Console.ReadLine();
                        break;
                    }
                case "3":
                case "travel":
                    {
                        Console.WriteLine("What planet would you like to travel to?\n");
                        Console.WriteLine("1]  Planet X3");
                        Console.WriteLine("2]  Planet Viz");
                        Console.WriteLine("3]  Planet Horn");
                        Console.WriteLine("4]  Planet Gil");
                        Console.WriteLine("5]  Cancel");
                        int c = Int32.Parse(Console.ReadLine());

                        switch (c)
                        {
                            case 1:
                                {
                                    Console.Clear();
                                    X3 x3 = new X3();
                                    x3.X3Welcome();
                                    break;
                                }
                            case 2:
                                {
                                    Console.Clear();
                                    Viz viz = new Viz();
                                    viz.VizWelcome();
                                    break;
                                }
                            case 3:
                                {
                                    Console.Clear();
                                    Horn horn = new Horn();
                                    horn.HornWelcome();
                                    break;
                                }
                            case 4:
                                {
                                    Console.Clear();
                                    Gil gil = new Gil();
                                    gil.GilWelcome();
                                    break;
                                }
                            case 5:
                                {
                                    Console.Clear();
                                    DoomMarket();
                                    break;
                                }
                            default:
                                {
                                    Console.WriteLine("Command not recognized. Try again.");
                                    break;
                                }
                        }
                        break;
                    }
            }
        }
        void Typewrite(string message)
        {
            for (int i = 0; i < message.Length; i++)
            {
                Console.Write(message[i]);
                System.Threading.Thread.Sleep(50);
            }
        }
    }
}
