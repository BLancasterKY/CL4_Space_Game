﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGame
{
    public class Player
    {
        public void Welcome()
        {
            Console.WriteLine("Welcome to the Space Game!");
            Console.WriteLine("Press 'Enter' to continue");
            Console.ReadLine();
            Console.Clear();
        }
        public void Name()
        {
            Console.WriteLine("Enter your username");
            string user = Console.ReadLine();
            Console.WriteLine($"Your username is {user}");
            Console.WriteLine("Press enter to continue");
            Console.ReadLine();
            Console.Clear();
        }
    }
    class PlayerInventory
    {
        public List<string> PlayerInv = new List<string>();
        public void PIdisplay()
        {
            for (int i = 0; i < PlayerInv.Count; i++)
            {
                Console.WriteLine($"{PlayerInv[i]}");
            }
        }
    }
    
}
