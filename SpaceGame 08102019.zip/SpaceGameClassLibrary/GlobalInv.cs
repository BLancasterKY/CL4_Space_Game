﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace SpaceGame
{
    public class GlobalInventoryPrices
    {
        public int PlayerCash { get; set; }
        public int FenceCash { get; set; }
        public int X3Cash { get; set; }
        public int CopperWatch { get; set; }
        public int CopperPlate { get; set; }
        public int CopperStool { get; set; }
        public int CopperBuckle { get; set; }
        public int CopperStatue { get; set; }

        public int VizCash { get; set; }
        public int BronzeWatch { get; set; }
        public int BronzePlate { get; set; }
        public int BronzeStool { get; set; }
        public int BronzeBuckle { get; set; }
        public int BronzeStatue { get; set; }

        public int HornCash { get; set; }
        public int SilverWatch { get; set; }
        public int SilverPlate { get; set; }
        public int SilverStool { get; set; }
        public int SilverBuckle { get; set; }
        public int SilverStatue { get; set; }

        public int GilCash { get; set; }
        public int GoldWatch { get; set; }
        public int GoldPlate { get; set; }
        public int GoldStool { get; set; }
        public int GoldBuckle { get; set; }
        public int GoldStatue { get; set; }

        public int DoomCash { get; set; }
        public int PlatinumWatch { get; set; }
        public int PlatinumPlate { get; set; }
        public int PlatinumStool { get; set; }
        public int PlatinumBuckle { get; set; }
        public int PlatinumStatue { get; set; }


        public GlobalInventoryPrices()
        {
            this.PlayerCash = 500;
            this.FenceCash = 5000;
            this.X3Cash = 500;
            this.CopperWatch = 85;
            this.CopperPlate = 20;
            this.CopperStool = 50;
            this.CopperBuckle = 25;
            this.CopperStatue = 150;

            this.VizCash = 600;
            this.BronzeWatch = 95;
            this.BronzePlate = 25;
            this.BronzeStool = 60;
            this.BronzeBuckle = 30;
            this.BronzeStatue = 175;

            this.HornCash = 700;
            this.SilverWatch = 110;
            this.SilverPlate = 35;
            this.SilverStool = 75;
            this.SilverBuckle = 40;
            this.SilverStatue = 200;

            this.GilCash = 800;
            this.GoldWatch = 125;
            this.GoldPlate = 45;
            this.GoldStool = 85;
            this.GoldBuckle = 50;
            this.GoldStatue = 225;

            this.DoomCash = 800;
            this.PlatinumWatch = 150;
            this.PlatinumPlate = 60;
            this.PlatinumStool = 100;
            this.PlatinumBuckle = 65;
            this.PlatinumStatue = 250;
        }
    }
    public class GlobalInventory 
    {
        public string CopperWatch { get; set; }
        public string CopperPlate { get; set; }
        public string CopperStool { get; set; }
        public string CopperBuckle { get; set; }
        public string CopperStatue { get; set; }

        public string BronzeWatch { get; set; }
        public string BronzePlate { get; set; }
        public string BronzeStool { get; set; }
        public string BronzeBuckle { get; set; }
        public string BronzeStatue { get; set; }

        public string SilverWatch { get; set; }
        public string SilverPlate { get; set; }
        public string SilverStool { get; set; }
        public string SilverBuckle { get; set; }
        public string SilverStatue { get; set; }

        public string GoldWatch { get; set; }
        public string GoldPlate { get; set; }
        public string GoldStool { get; set; }
        public string GoldBuckle { get; set; }
        public string GoldStatue { get; set; }

        public string PlatinumWatch { get; set; }
        public string PlatinumPlate { get; set; }
        public string PlatinumStool { get; set; }
        public string PlatinumBuckle { get; set; }
        public string PlatinumStatue { get; set; }

        public GlobalInventory()
        {
            this.CopperWatch = "Copper Watch        $85";
            this.CopperPlate = "Copper Plate        $20";
            this.CopperStool = "Copper Stool        $50";
            this.CopperBuckle = "Copper Buckle       $25";
            this.CopperStatue = "Copper Statue       $150";

            this.BronzeWatch = "Bronze Watch";
            this.BronzePlate = "Bronze Plate";
            this.BronzeStool = "Bronze Stool";
            this.BronzeBuckle = "Bronze Buckle";
            this.BronzeStatue = "Bronze Statue";

            this.SilverWatch = "Silver Watch";
            this.SilverPlate = "Silver Plate";
            this.SilverStool = "Silver Stool";
            this.SilverBuckle = "Silver Buckle";
            this.SilverStatue = "Silver Statue";

            this.GoldWatch = "Gold Watch";
            this.GoldPlate = "Gold Plate";
            this.GoldStool = "Gold Stool";
            this.GoldBuckle = "Gold Buckle";
            this.GoldStatue = "Gold Statue";

            this.PlatinumWatch = "Platinum Watch";
            this.PlatinumPlate = "Platinum Plate";
            this.PlatinumStool = "Platinum Stool";
            this.PlatinumBuckle = "Platinum Buckle";
            this.PlatinumStatue = "Platinum Statue";

        }
    }
}

