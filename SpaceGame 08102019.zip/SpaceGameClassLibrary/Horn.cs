﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGame
{
    class Horn
    {
        GlobalInventoryPrices GIP = new GlobalInventoryPrices();
        GlobalInventory GI = new GlobalInventory();
        PlayerInventory PI = new PlayerInventory();
        public void HornWelcome()
        {
            string Choice;

            Typewrite("You arrive at planet Horn and look around but see very few people around");
            Typewrite("\nAn old man walks up to you and tells you everyone has gone underground for the summer.");
            Typewrite("\nYou head underground and see a giant marketplace.");
            Typewrite("\n*Everyone here looks extremely wealthy.. \nI could probably aquire a lof of goods here*");
            Typewrite("\nWhat would you like to do?");
            Typewrite("\n1. Go to the next planet");
            Typewrite("\n2. Go to the nearest vendor.");
            Typewrite("Choice: ");
            Choice = Console.ReadLine().ToLower();
            Console.Clear();

            switch (Choice)
            {
                case "1":
                case "one":
                    Console.Clear();
                    Gil gil = new Gil();
                    gil.GilWelcome();
                    break;
                case "2":
                case "two":
                    Console.Clear();
                    HornMarket();
                    break;
                default:
                    Typewrite("Please choose '1' or '2'!");
                    Typewrite("Press 'Enter' to try again.");
                    Console.ReadLine();
                    Console.Clear();
                    HornWelcome();
                    break;
            }
        }
        public void HornMarket()
        {
            Typewrite("Hello young traveller! Please feel free to browse around! \nIf you have any questions feel free to ask!");
            Typewrite("\nWhat would you like to do?\n");
            Typewrite("\n1] >> Buy Items ");
            Typewrite("\n2] >> Sell Items ");
            Typewrite("\n3] >> Travel");
            string input = Console.ReadLine().ToLower();
            Console.Clear();

            switch (input)
            {
                case "1":
                case "buy":
                    {
                        Typewrite($"\nYou have ${GIP.PlayerCash}\n");
                        Console.WriteLine("What would you like to buy?");
                        Console.WriteLine("       Item                 Cost     ");
                        Console.WriteLine("      -------              ------    ");
                        Console.WriteLine("1]  Silver Watch            $110     ");
                        Console.WriteLine("2]  Silver Plate            $35      ");
                        Console.WriteLine("3]  Silver Stool            $75      ");
                        Console.WriteLine("4]  Silver Buckle           $40      ");
                        Console.WriteLine("5]  Silver Statue           $200     ");
                        Console.WriteLine("6]  Cancel purchase                  ");
                        int choice = Int32.Parse(Console.ReadLine());

                        switch (choice)
                        {
                            case 1:
                                {
                                    if (GIP.PlayerCash >= 110)
                                    {
                                        Console.WriteLine("You bought a silver watch for $110.\n");
                                        GIP.PlayerCash -= GIP.SilverWatch;
                                        GIP.HornCash += GIP.SilverWatch;
                                        PI.PlayerInv.Add(GI.SilverWatch);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        HornMarket();
                                    }
                                    if (GIP.PlayerCash < 110)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.\n");
                                        Console.WriteLine("Maybe try selling a few of your items.");
                                        Console.WriteLine("Press enter to return to the market.\n");
                                        Console.ReadLine();
                                        Console.Clear();
                                        HornMarket();
                                    }
                                    break;
                                }
                            case 2:
                                {
                                    if (GIP.PlayerCash >= 35)
                                    {
                                        Console.WriteLine("You bought a silver plate for $35.\n");
                                        GIP.PlayerCash -= GIP.SilverPlate;
                                        GIP.HornCash += GIP.SilverPlate;
                                        PI.PlayerInv.Add(GI.SilverPlate);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        HornMarket();
                                    }
                                    if (GIP.PlayerCash < 35)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        HornMarket();
                                    }
                                    break;
                                }
                            case 3:
                                {
                                    if (GIP.PlayerCash >= 75)
                                    {
                                        Console.WriteLine("You bought a silver stool for $75.\n");
                                        GIP.PlayerCash -= GIP.SilverStool;
                                        GIP.HornCash += GIP.SilverStool;
                                        PI.PlayerInv.Add(GI.SilverStool);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        HornMarket();
                                    }
                                    if (GIP.PlayerCash < 75)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        HornMarket();
                                    }
                                    break;
                                }
                            case 4:
                                {
                                    if (GIP.PlayerCash >= 40)
                                    {
                                        Console.WriteLine("You bought a silver buckle for $40.\n");
                                        GIP.PlayerCash -= GIP.SilverBuckle;
                                        GIP.HornCash += GIP.SilverBuckle;
                                        PI.PlayerInv.Add(GI.SilverBuckle);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        HornMarket();
                                    }
                                    if (GIP.PlayerCash < 40)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        HornMarket();
                                    }
                                    break;
                                }
                            case 5:
                                {
                                    if (GIP.PlayerCash >= 200)
                                    {
                                        Console.WriteLine("You bought a silver statue for $200.\n");
                                        GIP.PlayerCash -= GIP.SilverStatue;
                                        GIP.HornCash += GIP.SilverStatue;
                                        PI.PlayerInv.Add(GI.SilverStatue);
                                        Console.WriteLine($"You now have ${GIP.PlayerCash}\n");
                                        Console.WriteLine("Press enter to return to the store.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        HornMarket();
                                    }
                                    if (GIP.PlayerCash < 200)
                                    {
                                        Console.WriteLine("You dont have the money to buy this right now.");
                                        Console.WriteLine("Maybe try selling a few of your items.\n");
                                        Console.WriteLine("Press enter to return to the market.");
                                        Console.ReadLine();
                                        Console.Clear();
                                        HornMarket();
                                    }
                                    break;
                                }
                            case 6:
                                {
                                    HornMarket();
                                    break;
                                }

                        }

                        break;
                    }
                case "2":
                case "sell":
                    {
                        Console.WriteLine("        YOUR INVENTORY        ");
                        Console.WriteLine("==============================");
                        Console.WriteLine("   Item             Cost     ");
                        Console.WriteLine("  -------          ------    ");
                        PI.PIdisplay();
                        Sell sell2 = new Sell();
                        sell2.SellInv();
                        Console.ReadLine();
                        break;
                    }
                case "3":
                case "travel":
                    {
                        Console.WriteLine("What planet would you like to travel to?\n");
                        Console.WriteLine("1]  Planet X3");
                        Console.WriteLine("2]  Planet Viz");
                        Console.WriteLine("3]  Planet Gil");
                        Console.WriteLine("4]  Planet DOOM");
                        Console.WriteLine("5]  Cancel");
                        int c = Int32.Parse(Console.ReadLine());

                        switch (c)
                        {
                            case 1:
                                {
                                    Console.Clear();
                                    X3 x3 = new X3();
                                    x3.X3Welcome();
                                    break;
                                }
                            case 2:
                                {
                                    Console.Clear();
                                    Viz viz = new Viz();
                                    viz.VizWelcome();
                                    break;
                                }
                            case 3:
                                {
                                    Console.Clear();
                                    Gil gil = new Gil();
                                    gil.GilWelcome();
                                    break;
                                }
                            case 4:
                                {
                                    Console.Clear();
                                    DOOM doom = new DOOM();
                                    doom.DoomWelcome();
                                    break;
                                }
                            case 5:
                                {
                                    Console.Clear();
                                    HornMarket();
                                    break;
                                }
                            default:
                                {
                                    Console.WriteLine("Command not recognized. Try again.");
                                    break;
                                }

                        }
                        break;
                    }
            }
        }
        void Typewrite(string message)
        {
            for (int i = 0; i < message.Length; i++)
            {
                Console.Write(message[i]);
                System.Threading.Thread.Sleep(50);
            }
        }
    }
}
