﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGame
{
    class Program
    {
        static void Main()
        {
            Player player = new Player();
            player.Welcome();
            player.Name();

            X3 x3 = new X3();
            x3.X3Prison();
            x3.X3Welcome();
            x3.X3Market();
        }
    }
}
